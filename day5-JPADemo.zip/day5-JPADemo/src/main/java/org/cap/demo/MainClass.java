package org.cap.demo;

import java.text.ParseException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) throws ParseException {
		

        EntityManagerFactory emf = 
        		Persistence.createEntityManagerFactory("test");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction= em.getTransaction();
        
        transaction.begin();
        
        Customer customer=new Customer("tom");
        Address address=new Address("Hyderabad");
        customer.setAddress(address);
        address.setCustomer(customer);
        em.persist(customer);
        em.persist(address);
        transaction.commit();
        em.close();
	}

}
