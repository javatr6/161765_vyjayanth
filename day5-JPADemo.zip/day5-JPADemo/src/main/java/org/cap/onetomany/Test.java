package org.cap.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("test");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Company tcs=new Company("TATA consulting services");
		Company capg=new Company("Capgemini services pvt ltd");
		Employee employee=new Employee(1001,"tom",tcs);
		
		Employee employee1=new Employee(1002,"jerry",tcs);
		
		Employee employee2=new Employee(1003,"clark",capg);
		
		Employee employee3=new Employee(1004,"steve",capg);
		
		Employee employee4=new Employee(1005,"david",tcs);
		entityManager.persist(tcs);
		entityManager.persist(capg);
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		entityManager.persist(employee4);
		transaction.commit();
		entityManager.close();

	}

}
