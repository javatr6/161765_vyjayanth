package org.cap.demo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="customerInfo")
public class Customer {
	
	@Id
	private	Integer customerId;
	@Column(name="name",nullable=false,length=25)
	private	String customerName;
	private	Double regFees;
	@Temporal(TemporalType.DATE)
	private	Date regDate;

	public Customer() {

	}

	public Customer(Integer customerId, String customerName, Double regFees, Date regDate) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.regFees = regFees;
		this.regDate = regDate;
	}
	
	public Integer getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public Double getRegFees() {
		return regFees;
	}

	public void setRegFees(Double regFees) {
		this.regFees = regFees;
	}
	
	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", regFees=" + regFees
				+ ", regDate=" + regDate + "]";
	}


}
