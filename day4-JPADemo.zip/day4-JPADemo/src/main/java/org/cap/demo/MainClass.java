package org.cap.demo;

import java.text.ParseException;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) throws ParseException {
		

        EntityManagerFactory emf = 
        		Persistence.createEntityManagerFactory("test");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction= em.getTransaction();
        
        transaction.begin();
        /*Customer c1=new Customer(100, "Tom", 1000.0,new SimpleDateFormat("dd/MM/yyyy").parse("10/10/1996"));
        Customer c2=new Customer(101, "Jerry", 2000.0, new SimpleDateFormat("dd/MM/yyyy").parse("05/10/1996"));
        Customer c3=new Customer(102, "Scott", 1500.0, new SimpleDateFormat("dd/MM/yyyy").parse("01/01/1991"));
        */Customer c4=new Customer(103, "Tim", 1050.0,new Date());
       
       /* em.persist(c1);
        em.persist(c2);
        em.persist(c3);
       */ em.persist(c4);
        
        transaction.commit();
        em.close();
	}

}
